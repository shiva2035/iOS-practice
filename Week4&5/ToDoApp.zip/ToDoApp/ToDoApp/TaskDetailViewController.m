//
//  TaskDetailViewController.m
//  ToDoApp
//
//  Created by Shiva Kumar K on 7/24/16.
//  Copyright © 2016 Accolite. All rights reserved.
//

#import "TaskDetailViewController.h"
#import <CoreData/CoreData.h>

@interface TaskDetailViewController ()

@end

@implementation TaskDetailViewController

@synthesize task;

- (NSManagedObjectContext *)managedObjectContext {
    
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}


- (IBAction)cancel:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)save:(id)sender {
    
    NSManagedObjectContext *context = [self managedObjectContext];
    if (self.task) {
        // Update existing device
        [self.task setValue:self.label.text forKey:@"label"];
        [self.task setValue:self.desc.text forKey:@"desc"];
        [self.task setValue:self.status.text forKey:@"desc"];
        
    } else {
        // Create a new device
        NSManagedObject *newTask = [NSEntityDescription insertNewObjectForEntityForName:@"Task" inManagedObjectContext:context];
        
        [newTask setValue:self.label.text forKey:@"label"];
        [newTask setValue:self.desc.text forKey:@"desc"];
        [newTask setValue:self.status.text forKey:@"desc"];
    }
    
    NSError *error = nil;
    // Save the object to persistent store
    if (![context save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.task) {
        [self.label setText:[self.task valueForKey:@"label"]];
        [self.desc setText:[self.task valueForKey:@"desc"]];
        [self.status setText:[self.task valueForKey:@"desc"]];
    }
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
