//
//  TaskDetailViewController.h
//  ToDoApp
//
//  Created by Shiva Kumar K on 7/24/16.
//  Copyright © 2016 Accolite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreData/CoreData.h"

@interface TaskDetailViewController : UIViewController

@property(weak,nonatomic) IBOutlet UITextField *label;
@property(weak,nonatomic) IBOutlet UITextField *desc;
@property(weak,nonatomic) IBOutlet UITextField *status;
@property (weak, nonatomic) IBOutlet UIDatePicker *dueDate;


@property(strong) NSManagedObject *task;

- (IBAction)save:(id)sender;
- (IBAction)cancel:(id)sender;


@end
